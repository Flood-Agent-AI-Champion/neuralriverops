BaseDataset
===========

.. automodule:: neuralhydrology.datasetzoo.basedataset
   :members:
   :undoc-members:
   :show-inheritance: