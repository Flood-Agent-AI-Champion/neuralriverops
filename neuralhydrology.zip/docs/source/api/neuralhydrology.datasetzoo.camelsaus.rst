CamelsAUS
=========

.. automodule:: neuralhydrology.datasetzoo.camelsaus
   :members:
   :undoc-members:
   :show-inheritance: