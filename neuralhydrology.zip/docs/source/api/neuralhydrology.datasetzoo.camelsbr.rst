CamelsBR
========

.. automodule:: neuralhydrology.datasetzoo.camelsbr
   :members:
   :undoc-members:
   :show-inheritance: