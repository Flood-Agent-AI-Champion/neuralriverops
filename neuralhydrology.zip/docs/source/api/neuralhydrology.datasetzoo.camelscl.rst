CamelsCL
========

.. automodule:: neuralhydrology.datasetzoo.camelscl
   :members:
   :undoc-members:
   :show-inheritance:
