CamelsGB
========

.. automodule:: neuralhydrology.datasetzoo.camelsgb
   :members:
   :undoc-members:
   :show-inheritance: