GenericDataset
==============

.. automodule:: neuralhydrology.datasetzoo.genericdataset
   :members:
   :undoc-members:
   :show-inheritance:
