HourlyCamelsUS
==============

.. automodule:: neuralhydrology.datasetzoo.hourlycamelsus
   :members:
   :undoc-members:
   :show-inheritance: