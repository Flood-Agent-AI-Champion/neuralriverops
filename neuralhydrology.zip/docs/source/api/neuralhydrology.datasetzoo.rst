nh.datasetzoo
=============

.. automodule:: neuralhydrology.datasetzoo
   :members:
   :undoc-members:
   :show-inheritance:

.. toctree::
   :maxdepth: 4

   neuralhydrology.datasetzoo.basedataset
   neuralhydrology.datasetzoo.camelsaus
   neuralhydrology.datasetzoo.camelsbr
   neuralhydrology.datasetzoo.camelscl
   neuralhydrology.datasetzoo.camelsgb
   neuralhydrology.datasetzoo.camelsus
   neuralhydrology.datasetzoo.caravan
   neuralhydrology.datasetzoo.genericdataset
   neuralhydrology.datasetzoo.hourlycamelsus
   neuralhydrology.datasetzoo.lamah
   neuralhydrology.datasetzoo.template
