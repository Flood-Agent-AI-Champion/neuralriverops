TemplateDataset
===============

.. automodule:: neuralhydrology.datasetzoo.template
   :members:
   :undoc-members:
   :show-inheritance: