nh.datautils
============

.. automodule:: neuralhydrology.datautils
   :members:
   :undoc-members:
   :show-inheritance:

.. toctree::
   :maxdepth: 4

   neuralhydrology.datautils.climateindices
   neuralhydrology.datautils.pet
   neuralhydrology.datautils.utils
