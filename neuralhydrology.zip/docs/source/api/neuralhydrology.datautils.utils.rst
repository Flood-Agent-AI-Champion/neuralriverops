utils
=====

.. automodule:: neuralhydrology.datautils.utils
   :members:
   :undoc-members:
   :show-inheritance:
