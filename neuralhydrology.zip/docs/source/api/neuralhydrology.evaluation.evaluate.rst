evaluate
========

.. automodule:: neuralhydrology.evaluation.evaluate
   :members:
   :undoc-members:
   :show-inheritance:
