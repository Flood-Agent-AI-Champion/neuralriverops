nh.evaluation
=============

.. automodule:: neuralhydrology.evaluation
   :members:
   :undoc-members:
   :show-inheritance:

.. toctree::
   :maxdepth: 4

   neuralhydrology.evaluation.evaluate
   neuralhydrology.evaluation.metrics
   neuralhydrology.evaluation.plots
   neuralhydrology.evaluation.signatures
   neuralhydrology.evaluation.tester
