signatures
==========

.. automodule:: neuralhydrology.evaluation.signatures
   :members:
   :undoc-members:
   :show-inheritance:
