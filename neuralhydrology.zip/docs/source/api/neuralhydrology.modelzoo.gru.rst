GRU
===

.. automodule:: neuralhydrology.modelzoo.gru
   :members:
   :undoc-members:
   :show-inheritance:
