MultiheadForecastLSTM
=====================

.. automodule:: neuralhydrology.modelzoo.multihead_forecast_lstm
   :members:
   :undoc-members:
   :show-inheritance:
