TemplateModel
=============

.. automodule:: neuralhydrology.modelzoo.template
   :members:
   :undoc-members:
   :show-inheritance:
