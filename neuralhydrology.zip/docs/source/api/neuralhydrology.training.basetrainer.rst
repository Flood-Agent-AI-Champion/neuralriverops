BaseTrainer
===========

.. automodule:: neuralhydrology.training.basetrainer
   :members:
   :undoc-members:
   :show-inheritance:
