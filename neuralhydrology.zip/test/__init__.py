from typing import Union

# Type alias to allow explicit type annotations of fixtures that don't break an IDE's type inspections
Fixture = Union
